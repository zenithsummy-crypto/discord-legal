# Pages légales pour une application Discord privée

Fichiers :
- index.html
- terms.html
- privacy.html

Avant de publier :
1. Remplace les mentions génériques par le nom exact de ton application.
2. Vérifie que la politique de confidentialité décrit uniquement les données réellement utilisées par ton bot.
3. Ajoute un vrai moyen de contact.
4. Héberge ces fichiers sur un service permettant des pages HTTPS publiques.
5. Mets les URLs HTTPS de terms.html et privacy.html dans le Discord Developer Portal.

Ces modèles ne remplacent pas un avis juridique.
